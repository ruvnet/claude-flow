// Generated scalar integer recovery. Not a proof or a memory safety guarantee.
// Requires original ABI/launch, valid aligned race-free global memory, 64-bit CUDA.
#include <stdint.h>
static_assert(sizeof(uintptr_t) == 8, "RuRE recovery requires 64-bit pointers");
namespace rure_detail {
// Byte accesses avoid C++ strict-aliasing violations and preserve PTX little endian bits.
static __device__ inline uint32_t load32(uint64_t address) {
  const unsigned char* p = reinterpret_cast<const unsigned char*>(static_cast<uintptr_t>(address));
  uint32_t value = 0;
  for (unsigned i = 0; i < 4; ++i) value |= static_cast<uint32_t>(p[i]) << (8 * i);
  return value;
}
static __device__ inline uint64_t load64(uint64_t address) {
  const unsigned char* p = reinterpret_cast<const unsigned char*>(static_cast<uintptr_t>(address));
  uint64_t value = 0;
  for (unsigned i = 0; i < 8; ++i) value |= static_cast<uint64_t>(p[i]) << (8 * i);
  return value;
}
static __device__ inline void store32(uint64_t address, uint32_t value) {
  unsigned char* p = reinterpret_cast<unsigned char*>(static_cast<uintptr_t>(address));
  for (unsigned i = 0; i < 4; ++i) p[i] = static_cast<unsigned char>(value >> (8 * i));
}
static __device__ inline void store64(uint64_t address, uint64_t value) {
  unsigned char* p = reinterpret_cast<unsigned char*>(static_cast<uintptr_t>(address));
  for (unsigned i = 0; i < 8; ++i) p[i] = static_cast<unsigned char>(value >> (8 * i));
}
static __device__ inline int64_t signed32(uint32_t value) {
  return static_cast<int64_t>(value) - static_cast<int64_t>(value >> 31) * 4294967296LL;
}
}
extern "C" __global__ void rure_kernel_0(uint64_t rure_arg_0, uint64_t rure_arg_1, uint64_t rure_arg_2, uint32_t rure_arg_3, uint64_t rure_arg_4) {
  uint32_t rure_reg_0;
  uint32_t rure_reg_1;
  uint32_t rure_reg_2;
  uint32_t rure_reg_3;
  uint32_t rure_reg_4;
  uint32_t rure_reg_5;
  uint32_t rure_reg_6;
  uint32_t rure_reg_7;
  uint32_t rure_reg_8;
  uint32_t rure_reg_9;
  uint32_t rure_reg_10;
  uint32_t rure_reg_11;
  uint32_t rure_reg_12;
  uint32_t rure_reg_13;
  uint32_t rure_reg_14;
  uint32_t rure_reg_15;
  uint64_t rure_reg_16;
  uint64_t rure_reg_17;
  uint64_t rure_reg_18;
  uint64_t rure_reg_19;
  uint64_t rure_reg_20;
  uint64_t rure_reg_21;
  uint64_t rure_reg_22;
  uint64_t rure_reg_23;
  uint64_t rure_reg_24;
  uint64_t rure_reg_25;
  uint64_t rure_reg_26;
  uint64_t rure_reg_27;
  uint64_t rure_reg_28;
  uint64_t rure_reg_29;
  uint64_t rure_reg_30;
  uint64_t rure_reg_31;
  bool rure_reg_32;
  bool rure_reg_33;
  bool rure_reg_34;
  bool rure_reg_35;
  bool rure_reg_36;
  bool rure_reg_37;
  bool rure_reg_38;
  bool rure_reg_39;
  rure_reg_16 = rure_arg_0;
  rure_reg_17 = rure_arg_1;
  rure_reg_18 = rure_arg_2;
  rure_reg_1 = rure_arg_3;
  rure_reg_0 = static_cast<uint32_t>(blockIdx.x);
  rure_reg_6 = static_cast<uint32_t>(blockDim.x);
  rure_reg_7 = static_cast<uint32_t>(threadIdx.x);
  rure_reg_0 = static_cast<uint32_t>(static_cast<uint64_t>(rure_reg_0) * static_cast<uint64_t>(rure_reg_6) + static_cast<uint64_t>(rure_reg_7));
  rure_reg_32 = (rure_reg_0) >= (rure_reg_1);
  if (rure_reg_32) { goto rure_label_22; }
  rure_reg_16 = rure_reg_16;
  rure_reg_17 = rure_reg_17;
  rure_reg_18 = rure_reg_18;
  rure_reg_19 = static_cast<uint64_t>(rure_reg_0) * static_cast<uint64_t>(static_cast<uint32_t>(0x4ULL));
  rure_reg_20 = static_cast<uint64_t>(rure_reg_0) * static_cast<uint64_t>(static_cast<uint32_t>(0x4ULL));
  rure_reg_22 = static_cast<uint64_t>(static_cast<uint64_t>(rure_reg_16) + static_cast<uint64_t>(rure_reg_19));
  rure_reg_23 = static_cast<uint64_t>(static_cast<uint64_t>(rure_reg_17) + static_cast<uint64_t>(rure_reg_19));
  rure_reg_24 = static_cast<uint64_t>(static_cast<uint64_t>(rure_reg_18) + static_cast<uint64_t>(rure_reg_20));
  rure_reg_2 = rure_detail::load32(rure_reg_22);
  rure_reg_3 = rure_detail::load32(rure_reg_23);
  rure_reg_4 = static_cast<uint32_t>(static_cast<uint64_t>(rure_reg_2) + static_cast<uint64_t>(static_cast<uint32_t>(0x8ULL)));
  rure_detail::store32(rure_reg_24, rure_reg_4);
rure_label_22:
  return;
}
