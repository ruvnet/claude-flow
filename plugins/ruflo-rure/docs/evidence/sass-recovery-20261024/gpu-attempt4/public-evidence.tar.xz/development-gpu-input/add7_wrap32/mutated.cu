// Recovered from cuobjdump text under explicit CUDA ABI assumptions. Not a binary decoder or proof.
#include <stdint.h>
static_assert(sizeof(uintptr_t) == 8, "64-bit CUDA pointers required");
namespace rure_sass_detail {
static __device__ inline uint64_t join(uint32_t lo, uint32_t hi) { return static_cast<uint64_t>(lo) | (static_cast<uint64_t>(hi) << 32); }
static __device__ inline int64_t signed32(uint32_t n) { return static_cast<int64_t>(n) - static_cast<int64_t>(n >> 31) * 4294967296LL; }
static __device__ inline uint32_t load32(uint64_t a) { const unsigned char* p = reinterpret_cast<const unsigned char*>(static_cast<uintptr_t>(a)); uint32_t v=0; for(unsigned i=0;i<4;i++) v |= static_cast<uint32_t>(p[i]) << (i*8); return v; }
static __device__ inline uint64_t load64(uint64_t a) { const unsigned char* p = reinterpret_cast<const unsigned char*>(static_cast<uintptr_t>(a)); uint64_t v=0; for(unsigned i=0;i<8;i++) v |= static_cast<uint64_t>(p[i]) << (i*8); return v; }
static __device__ inline void store32(uint64_t a,uint32_t v) { unsigned char* p=reinterpret_cast<unsigned char*>(static_cast<uintptr_t>(a)); for(unsigned i=0;i<4;i++) p[i]=static_cast<unsigned char>(v >> (i*8)); }
static __device__ inline void store64(uint64_t a,uint64_t v) { unsigned char* p=reinterpret_cast<unsigned char*>(static_cast<uintptr_t>(a)); for(unsigned i=0;i<8;i++) p[i]=static_cast<unsigned char>(v >> (i*8)); }
}

extern "C" __global__ void rure_sass_kernel_0(uint64_t rure_arg_0, uint64_t rure_arg_1, uint64_t rure_arg_2, uint32_t rure_arg_3, uint64_t rure_arg_4) {
  uint32_t rure_r0;
  uint32_t rure_r1;
  uint32_t rure_r2;
  uint32_t rure_r3;
  uint32_t rure_r4;
  uint32_t rure_r5;
  uint32_t rure_r6;
  uint32_t rure_r7;
  uint32_t rure_r8;
  uint32_t rure_r9;
  bool rure_p0;
  bool rure_p1;
  bool rure_p2;
  bool rure_p3;
  bool rure_p4;
  bool rure_p5;
  bool rure_p6;
  ;
  rure_r4 = static_cast<uint32_t>(blockIdx.x);
  rure_r3 = static_cast<uint32_t>(threadIdx.x);
  rure_r4 = static_cast<uint32_t>(static_cast<uint64_t>(rure_r4) * static_cast<uint64_t>(static_cast<uint32_t>(blockDim.x)) + static_cast<uint64_t>(rure_r3));
  rure_p0 = (rure_r4) >= (static_cast<uint32_t>(rure_arg_3));
  if (rure_p0) { return; }
  rure_r5 = static_cast<uint32_t>(0x4ULL);
  ;
  { const uint64_t rure_tmp_8 = (static_cast<uint64_t>(rure_r4) * static_cast<uint64_t>(rure_r5)) + rure_arg_0; rure_r2 = static_cast<uint32_t>(rure_tmp_8); rure_r3 = static_cast<uint32_t>(rure_tmp_8 >> 32); }
  rure_r2 = rure_sass_detail::load32(rure_sass_detail::join(rure_r2, rure_r3));
  { const uint64_t rure_tmp_10 = (static_cast<uint64_t>(rure_r4) * static_cast<uint64_t>(rure_r5)) + rure_arg_2; rure_r4 = static_cast<uint32_t>(rure_tmp_10); rure_r5 = static_cast<uint32_t>(rure_tmp_10 >> 32); }
  rure_r7 = static_cast<uint32_t>(static_cast<uint64_t>(rure_r2) + static_cast<uint64_t>(static_cast<uint32_t>(0x8ULL)) + static_cast<uint64_t>(0U));
  rure_sass_detail::store32(rure_sass_detail::join(rure_r4, rure_r5), rure_r7);
  return;
}
