"""Execute frozen original/recovered ELF cubins; no PTX-JIT substitution."""
if not __debug__:
    raise RuntimeError('Optimized Python is forbidden for guarded GPU execution')
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import signal
import tarfile
import time
from bounded_process import run_logged

ROOT=Path('/tmp/rure-sass')
DRIVER_SHA='b192f10ae51c47e338c74531b7238daa801b91aae75c752004b1ee2b0ac2aa05'
MODULE_SHA='d85b93f70711d17c5c44f97a93d4a04ac08549cc253c70c88ab84294757287c3'
ENV={'PATH':'/usr/local/cuda/bin:/usr/local/bin:/usr/bin:/bin','HOME':'/root','LANG':'C','LC_ALL':'C','LD_LIBRARY_PATH':'/usr/local/cuda/lib64:/usr/local/nvidia/lib:/usr/local/nvidia/lib64:/usr/lib/x86_64-linux-gnu'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def interrupted(signum, frame):
    raise TimeoutError('remote command timeout or cancellation')
signal.signal(signal.SIGTERM, interrupted)

def extract(archive, destination):
    destination.mkdir()
    with tarfile.open(archive,'r:gz') as t:
        members=t.getmembers()
        assert len(members)<=1000 and sum(m.size for m in members)<=16*1024*1024
        for m in members:
            parts=Path(m.name).parts
            assert m.isfile() and parts and not m.name.startswith('/') and '..' not in parts and '\\' not in m.name
            target=destination.joinpath(*parts);target.parent.mkdir(parents=True,exist_ok=True)
            assert not target.exists();target.write_bytes(t.extractfile(m).read())

parser=argparse.ArgumentParser();parser.add_argument('--split',choices=['development','confirmation'],required=True);args=parser.parse_args()
split=args.split;started=time.time();deadline=time.monotonic()+240
receipt={'schemaVersion':1,'status':'incomplete','split':split,'startedAt':started,'commands':[],'actualBilledUsd':None}
logs=ROOT/(split+'-logs');logs.mkdir();exports=ROOT/(split+'-exports');exports.mkdir()
os.umask(0o077)

def run(argv, expected=0, timeout=60):
    remaining=min(timeout,deadline-time.monotonic())
    assert remaining>0,'GPU execution deadline'
    path=logs/(str(len(receipt['commands']))+'.log')
    result=run_logged(argv,path,1_000_000,remaining,ENV)
    receipt['commands'].append({'argv':argv,**result,'logFile':path.name})
    assert result['exitCode']==expected,'unexpected command exit'
    return path.read_text()

try:
    lock_path=ROOT/('execution-lock-'+split+'.json');lock=json.loads(lock_path.read_text());receipt['executionLockSha256']=sha(lock_path)
    assert lock['moduleSha256']==MODULE_SHA and lock['driverSha256']==DRIVER_SHA and lock['split']==split
    bundle_archive=ROOT/('gpu-'+split+'.tar.gz');native_archive=ROOT/('native-'+split+'.tar.gz')
    assert sha(bundle_archive)==lock['gpuArchiveSha256'] and sha(native_archive)==lock['nativeArchiveSha256']
    bundle=ROOT/('gpu-'+split);native=ROOT/('native-'+split);extract(bundle_archive,bundle);extract(native_archive,native)
    manifest_path=bundle/'gpu-manifest.json';native_path=native/'native-manifest.json'
    assert sha(manifest_path)==lock['gpuManifestSha256'] and sha(native_path)==lock['nativeManifestSha256']
    manifest=json.loads(manifest_path.read_text());prior=json.loads(native_path.read_text())
    assert manifest['moduleSha256']==MODULE_SHA and manifest['driverSha256']==DRIVER_SHA and manifest['architecture']=='sm_89'
    assert manifest['nativeManifestSha256']==sha(native_path)
    coverage=manifest['coverage']
    assert coverage['frozenKernelCount']==(4 if split=='development' else 6)
    assert coverage['admittedKernelCount']==len(manifest['kernels'])
    assert coverage['frozenKernelCount']==coverage['admittedKernelCount']+len(coverage['excluded'])
    receipt['coverage']=coverage
    receipt['coverageStatus']=coverage['status']
    receipt['executionStatus']='not-executed'
    names=(bundle/'kernels.txt').read_text().splitlines()
    assert names==[r['id'] for r in manifest['kernels']] and len(set(names))==len(names)
    assert (split=='development' and len(names)==4) or (split=='confirmation' and 1<=len(names)<=6)
    assert sha(bundle/'sass-recovery-gpu.cu')==DRIVER_SHA
    gpu=run(['nvidia-smi','--query-gpu=name,driver_version,memory.total,compute_cap','--format=csv,noheader'])
    assert len(gpu.strip().splitlines())==1 and gpu.strip().rsplit(',',1)[-1].strip()=='8.9'
    receipt['environment']=gpu.strip();receipt['executables']={}
    for tool in ['nvcc','ptxas','cuobjdump','compute-sanitizer']:
        executable=shutil.which(tool,path=ENV['PATH']);assert executable,'missing required tool'
        executable=Path(executable).resolve(strict=True);receipt['executables'][tool]={'path':str(executable),'sha256':sha(executable)}
        if tool in prior.get('executables',{}):
            assert receipt['executables'][tool]['sha256']==prior['executables'][tool]['sha256'],'native compiler tool changed'
    receipt['nvcc']=run(['nvcc','--version']);receipt['cuobjdump']=run(['cuobjdump','--version'])
    driver=ROOT/(split+'-driver');run(['nvcc','-std=c++17',str(bundle/'sass-recovery-gpu.cu'),'-lcuda','-o',str(driver)])
    receipt['compiledDriverSha256']=sha(driver);receipt['driverSourceSha256']=DRIVER_SHA
    artifacts=[]
    for row in manifest['kernels']:
        name=row['id'];assert name.replace('_','').isalnum()
        d=bundle/name;n=next(x for x in prior['kernels'] if x['id']==name)
        assert sha(d/'original.cubin')==row['originalCubinSha256']==n['cubinSha256']
        assert sha(d/'recovered.cu')==row['recoveredCudaSha256'] and sha(d/'case.txt')==row['caseSha256']
        assert all('/' not in file and sha(d/file)==digest for file,digest in row['files'].items())
        for ext in ['sass','elf']:
            dumped=run(['cuobjdump','-'+ext,str(d/'original.cubin')]);data=dumped.encode()
            assert hashlib.sha256(data).hexdigest()==n[ext+'Sha256']==sha(native/name/('original.'+ext)),'binary/export mismatch'
            (exports/(name+'.'+ext)).write_bytes(data)
        run(['nvcc','-std=c++17','-cubin','-arch=sm_89',str(d/'recovered.cu'),'-o',str(d/'recovered.cubin')])
        assert (d/'original.cubin').read_bytes()[:4]==b'\x7fELF' and (d/'recovered.cubin').read_bytes()[:4]==b'\x7fELF'
        for filename in ['original.cubin','recovered.cubin','recovered.cu']:shutil.copyfile(d/filename,exports/(name+'.'+filename))
        artifacts.append({'id':name,'originalCubinSha256':sha(d/'original.cubin'),'recoveredCubinSha256':sha(d/'recovered.cubin'),'recoveredCudaSha256':sha(d/'recovered.cu'),'sassSha256':n['sassSha256'],'elfSha256':n['elfSha256']})
    receipt['positive']=json.loads(run([str(driver),str(bundle)]))
    expected=manifest['expected'];positive=receipt['positive']
    assert positive['status']=='pass' and positive['kernels']==expected['kernels'] and positive['cases']==expected['cases'] and positive['elementComparisons']==expected['elementComparisonsBothVariants']
    if split=='development':
        mutation=manifest['semanticMutation'];d=bundle/mutation['id'];assert sha(d/'mutated.cu')==mutation['cudaSha256']
        run(['nvcc','-std=c++17','-cubin','-arch=sm_89',str(d/'mutated.cu'),'-o',str(d/'mutated.cubin')])
        log=run([str(driver),str(bundle),'--mutation'],expected=1)
        assert 'mismatch' in log and 'expected=7' in log and 'actual=8' in log
        shutil.copyfile(d/'mutated.cubin',exports/'add7_wrap32.mutated.cubin')
        receipt['negativeControl']={'exitCode':1,'log':log,'mutatedCudaSha256':sha(d/'mutated.cu'),'mutatedCubinSha256':sha(d/'mutated.cubin')}
    sanitizer=shutil.which('compute-sanitizer',path=ENV['PATH']);assert sanitizer,'required compute-sanitizer unavailable'
    receipt['sanitizerVersion']=run([sanitizer,'--version'])
    receipt['memcheckLog']=run([sanitizer,'--tool','memcheck','--error-exitcode','3',str(driver),str(bundle)],timeout=90)
    assert 'ERROR SUMMARY: 0 errors' in receipt['memcheckLog']
    for artifact in artifacts:
        d=bundle/artifact['id']
        assert sha(d/'original.cubin')==artifact['originalCubinSha256'],'original cubin changed during execution'
        assert sha(d/'recovered.cubin')==artifact['recoveredCubinSha256'],'recovered cubin changed during execution'
    assert sha(driver)==receipt['compiledDriverSha256'],'compiled driver changed during execution'
    if receipt.get('negativeControl'):
        assert sha(bundle/'add7_wrap32/mutated.cubin')==receipt['negativeControl']['mutatedCubinSha256'],'mutant changed during execution'
    receipt['postExecutionBinaryBindingVerified']=True
    receipt['artifacts']=artifacts;receipt['gpuManifest']=manifest;receipt['nativeManifestSha256']=sha(native_path)
    for source,name in [(driver,'compiled-driver'),(bundle/'sass-recovery-gpu.cu','sass-recovery-gpu.cu'),(manifest_path,'gpu-manifest.json'),(native_path,'native-manifest.json')]:shutil.copyfile(source,exports/name)
    (exports/'execution-manifest.json').write_text(json.dumps({'executionLock':lock,'compiledDriverSha256':receipt['compiledDriverSha256'],'artifacts':artifacts,'negativeControl':receipt.get('negativeControl')},indent=2)+'\n')
    files=list(exports.iterdir());assert all(f.is_file() and not f.is_symlink() for f in files) and sum(f.stat().st_size for f in files)<=16*1024*1024
    target=ROOT/(split+'-artifacts.tar.gz')
    with tarfile.open(target,'w:gz') as archive:
        for file in sorted(files):archive.add(file,arcname=file.name,recursive=False)
    assert target.stat().st_size<=2_000_000
    receipt['artifactArchiveSha256']=sha(target);receipt['artifactArchiveBytes']=target.stat().st_size
    receipt['executionStatus']='pass'
    receipt['status']='pass' if receipt['coverageStatus']=='complete' else 'partial-incomplete'
except Exception as error:
    receipt['status']='failed';receipt['error']={'type':type(error).__name__,'message':str(error)}
finally:
    receipt['elapsedSeconds']=time.time()-started
    receipt['logs']={p.name:p.read_text(errors='replace') for p in logs.iterdir() if p.is_file() and p.stat().st_size<=1_000_000}
    (ROOT/(split+'-result.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'executionStatus':receipt.get('executionStatus'),'coverageStatus':receipt.get('coverageStatus'),'coverage':receipt.get('coverage'),'split':split,'expected':receipt.get('gpuManifest',{}).get('expected'),'elapsedSeconds':receipt['elapsedSeconds']}))
raise SystemExit(0 if receipt.get('executionStatus')=='pass' else 1)
