"""Stage 1 only: compile frozen evaluator sources; export native inputs before recovery."""
if not __debug__:
    raise RuntimeError('Optimized Python is forbidden for guarded GPU execution')

from pathlib import Path
import hashlib
import json
import os
import signal
from bounded_process import run_logged
import tarfile
import time

ROOT = Path('/tmp/rure-sass')
SPECS_SHA256 = 'b54b32dadd8e391b232eca14a00203f526ad517934d7d021f58d096dc7d278a1'
PREPARER_SHA256 = '502b25818d4d5f079a6fec64a19aea38efee9671758a20d185f49167417c2e23'
PLAN_SHA256 = '2274fd56eb38d830c195e4be9d454731c1be2527c04d2d67d56bd377140fb1f3'
ARCHITECTURE = 'sm_89'
ENV = {'PATH': '/usr/local/cuda/bin:/usr/local/bin:/usr/bin:/bin', 'HOME': '/root', 'LANG': 'C', 'LC_ALL': 'C', 'LD_LIBRARY_PATH': '/usr/local/cuda/lib64:/usr/local/nvidia/lib:/usr/local/nvidia/lib64:/usr/lib/x86_64-linux-gnu'}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def interrupted(signum, frame):
    raise TimeoutError('remote command timeout or cancellation')
signal.signal(signal.SIGTERM, interrupted)
os.umask(0o077)
started = time.time()
receipt = {'schemaVersion': 1, 'status': 'incomplete', 'stage': 'native-preparation-before-translation',
           'architecture': ARCHITECTURE, 'startedAt': started, 'actualBilledUsd': None, 'commands': []}
try:
    assert sha(ROOT/'specs.tar.gz') == SPECS_SHA256
    assert sha(ROOT/'sass-recovery-prepare-native.py') == PREPARER_SHA256
    specs = ROOT/'specs'; specs.mkdir()
    with tarfile.open(ROOT/'specs.tar.gz', 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == 7 and sum(m.size for m in members) <= 128 * 1024
        for member in members:
            assert member.isfile() and '/' not in member.name and '\\' not in member.name
            assert member.name == 'confirmation-plan.json' or (member.name.startswith('confirm_') and member.name.endswith('.cu') and member.name[:-3].replace('_', '').isalnum())
            (specs/member.name).write_bytes(archive.extractfile(member).read())
    assert sha(specs/'confirmation-plan.json') == PLAN_SHA256
    probe_command = ['nvidia-smi', '--query-gpu=name,driver_version,memory.total,compute_cap', '--format=csv,noheader']
    probe = run_logged(probe_command, ROOT/'prepare-probe.log', 65536, 10, ENV)
    receipt['commands'].append({'argv': probe_command, **probe})
    assert probe['exitCode'] == 0
    probe_stdout=(ROOT/'prepare-probe.log').read_text()
    lines = probe_stdout.strip().splitlines()
    assert len(lines) == 1 and lines[0].rsplit(',', 1)[-1].strip() == '8.9', 'unexpected GPU architecture'
    receipt['environment'] = probe_stdout.strip()
    command = ['python3', str(ROOT/'sass-recovery-prepare-native.py'), '--spec-dir', str(specs), '--output', str(ROOT/'native'), '--arch', ARCHITECTURE]
    prepared = run_logged(command, ROOT/'prepare-command.log', 1_000_000, 190, ENV)
    receipt['commands'].append({'argv': command, **prepared, 'stdout': (ROOT/'prepare-command.log').read_text()})
    assert prepared['exitCode'] == 0, 'native preparation failed'
    native = ROOT/'native'; manifest = json.loads((native/'native-manifest.json').read_text())
    assert manifest['status'] == 'prepared-not-evaluated' and len(manifest['kernels']) == 6
    assert manifest['planSha256'] == PLAN_SHA256 and manifest['architecture'] == ARCHITECTURE
    receipt['nativeManifestSha256'] = sha(native/'native-manifest.json')
    receipt['translationInputManifestSha256'] = sha(native/'translation-input'/'translation-input.json')
    assert receipt['translationInputManifestSha256'] == manifest['translationInputManifestSha256']
    receipt['nativeArtifactsFrozenAt'] = manifest['nativeArtifactsFrozenAt']
    files = [p for p in native.rglob('*') if p.is_file()]
    assert len(files) == 32 and all(not p.is_symlink() for p in files)
    assert sum(p.stat().st_size for p in files) <= 16 * 1024 * 1024
    with tarfile.open(ROOT/'native-inputs.tar.gz', 'w:gz') as archive:
        for path in sorted(files): archive.add(path, arcname=str(path.relative_to(native)), recursive=False)
    artifact = ROOT/'native-inputs.tar.gz'
    assert artifact.stat().st_size <= 2_000_000
    receipt.update({'status': 'prepared-not-evaluated', 'kernelCount': 6, 'artifactFileCount': len(files),
                    'nativeArchiveBytes': artifact.stat().st_size, 'nativeArchiveSha256': sha(artifact),
                    'inputs': {'specsArchiveSha256': SPECS_SHA256, 'preparerSha256': PREPARER_SHA256, 'confirmationPlanSha256': PLAN_SHA256}})
except Exception as error:
    receipt['status'] = 'failed'; receipt['error'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    receipt['elapsedSeconds'] = time.time() - started
    (ROOT/'prepare-result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt.get(k) for k in ['status','kernelCount','nativeManifestSha256','translationInputManifestSha256','nativeArchiveSha256','elapsedSeconds']}))
raise SystemExit(0 if receipt['status'] == 'prepared-not-evaluated' else 1)
