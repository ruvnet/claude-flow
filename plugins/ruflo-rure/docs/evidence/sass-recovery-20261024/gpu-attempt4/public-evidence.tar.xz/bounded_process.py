"""Bounded subprocess I/O for host orchestration; no credentials or implicit env."""
if not __debug__:
    raise RuntimeError('Optimized Python is forbidden for guarded GPU execution')

import hashlib
import os
from pathlib import Path
import select
import signal
import subprocess
import time


def run_logged(argv, destination, limit, timeout, env, stdin_path=None, merge_stderr=True):
    """Keep at most limit bytes, terminate overflow/timeout, preserve bounded failure log."""
    if not isinstance(argv, list) or not argv or not all(isinstance(x, str) for x in argv):
        raise ValueError('argv must be a nonempty string list')
    if not 0 < limit <= 2_000_000 or not 0 < timeout <= 300:
        raise ValueError('invalid process bounds')
    if not set(env).issubset({'PATH', 'HOME', 'LANG', 'LC_ALL', 'LD_LIBRARY_PATH'}):
        raise ValueError('unexpected environment keys')
    destination = Path(destination)
    partial = destination.with_name(destination.name + '.partial')
    failed = destination.with_name(destination.name + '.failed')
    if any(p.exists() or p.is_symlink() for p in [destination, partial, failed]):
        raise FileExistsError('preserve existing process evidence')
    started = time.monotonic()
    stdin = open(stdin_path, 'rb') if stdin_path is not None else subprocess.DEVNULL
    process = subprocess.Popen(argv, stdin=stdin, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT if merge_stderr else subprocess.DEVNULL,
                               env=env, start_new_session=True)
    until = started + timeout
    written = 0
    try:
        with partial.open('xb') as output:
            while True:
                remaining = until - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('bounded process timeout')
                ready, _, _ = select.select([process.stdout], [], [], min(1, remaining))
                if not ready:
                    continue
                data = os.read(process.stdout.fileno(), min(65536, limit + 1 - written))
                if not data:
                    break
                available = limit - written
                output.write(data[:available])
                written += len(data)
                if written > limit:
                    raise ValueError('bounded process output limit exceeded')
        code = process.wait(timeout=max(0.001, until - time.monotonic()))
        partial.replace(destination)
        return {'exitCode': code, 'bytes': written,
                'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
                'elapsedSeconds': time.monotonic() - started}
    finally:
        # Every child owns a new process group, so descendants cannot outlive
        # the bounded compiler/sanitizer/SSH invocation. Never target a shared group.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        if process.poll() is None:
            process.wait(timeout=5)
        process.stdout.close()
        if stdin_path is not None:
            stdin.close()
        if partial.exists():
            partial.replace(failed)
